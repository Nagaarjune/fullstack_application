# fullstack_application
It contains sample serverless and react application
