module.exports.responseHandler = (statusCode,body)=>{
return {
  headers: {
    'Content-Type': 'application/json',
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Credentials": true,
  },
      statusCode : statusCode,
      body: JSON.stringify(body),
}
} 

//"aws-sdk": "^2.1185.0",
    // "serverless": "^3.28.1",
    // "serverless-offline": "^9.1.1",