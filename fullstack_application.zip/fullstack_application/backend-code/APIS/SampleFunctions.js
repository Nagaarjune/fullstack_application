'usestrict'
module.exports.helloWorld =async (event) => {
    return {
      headers: {
        'Content-Type': 'application/json',
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Credentials": true,
      },
      statusCode : 200,
      body: JSON.stringify(JSON.stringify({
        message: 'Go Serverless v1.0! Your function executed successfully!',
      })),
    };
  };