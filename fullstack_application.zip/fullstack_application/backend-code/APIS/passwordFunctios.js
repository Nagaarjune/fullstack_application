'use strict';
const { DynamoDB } = require('aws-sdk');
const AWS = require('aws-sdk');
const uuid = require('uuid')
const {responseHandler} = require('../responseHandler')


const DocumentClient = new DynamoDB.DocumentClient({ region: "us-east-1" });


module.exports.createPassword = async (event) =>{
  let newItems = JSON.parse(event.body)
  newItems['passwordId']=uuid.v4()
 await DocumentClient.put({
    TableName: "passwordTable",
    Item: newItems
  })
  .promise();
  return responseHandler(200,{
      message: 'New password created successfully',
    })
}

module.exports.getPassword = async (event) =>{
  const {id} = event.pathParameters
  var params = {
    TableName: 'passwordTable',
    Key: {'passwordId': id}
   };
   return new Promise((resolve,reject)=>{
   DocumentClient.get(params, function(err, data) {
     if (err) {
       console.log("Error", err);
       reject(err)
     } else {
       console.log("Success", data.Item);
       resolve({
          passwordDetails:data.Item
        })
      }
 })
}).then((data)=>{
return responseHandler(200,data)
 }).catch((err)=>{
return responseHandler(200,err)
 })
}

module.exports.getPasswords = async (event) =>{
  const params = {
    TableName: "passwordTable",
  };
  return new Promise((resolve,reject)=>{
    DocumentClient.scan(params, function (err, data) {
      if (err) {
        console.log("Error", err);
        reject("Error Occured")
      } else {
        console.log("Success", data);
        resolve(data.Items)
      }
    });
  }).then((data)=>{
    return responseHandler(200,data)
  }).catch((err)=>{
    return responseHandler(400,err)
  })
}





