'use strict';

const SampleFunctions = require('./APIS/SampleFunctions')
const StoreBookService = require('./APIS/passwordFunctios')

module.exports.helloWorld = SampleFunctions.helloWorld

module.exports.createPassword = StoreBookService.createPassword

module.exports.getPassword = StoreBookService.getPassword

module.exports.getPasswords = StoreBookService.getPasswords

