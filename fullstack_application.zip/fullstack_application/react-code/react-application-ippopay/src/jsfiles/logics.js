export function minimumStepsToMakePasswordStrong(password) {
    let count = 0;
    let hasLowercase = false;
    let hasUppercase = false;
    let hasDigit = false;
    let hasRepeatChars = false;
    let passwordLengthCheck=false
  
    // Check if password is less than 6 characters or greater than 20 characters
    if (password?.length >= 6 && password?.length <= 20){
      passwordLengthCheck=true
      
    }
    if(passwordLengthCheck) count++

    if(password?.length >=3){
    for (let i = 0; i < password.length - 2; i++) {
        if (password[i] === password[i+1] && password[i] === password[i+2]) {
          hasRepeatChars = true;
          break;
        }
      }
      if (!hasRepeatChars) count++;
    }
  
    // Check if password contains lowercase, uppercase and digits
    for (let i = 0; i < password.length; i++) {
      const charCode = password.charCodeAt(i);
      if (charCode >= 97 && charCode <= 122) { // lowercase letter
        hasLowercase = true;
      } else if (charCode >= 65 && charCode <= 90) { // uppercase letter
        hasUppercase = true;
      } else if (charCode >= 48 && charCode <= 57) { // digit
        hasDigit = true;
      }
    }
  
    if (hasLowercase) count++;
    if (hasUppercase) count++;
    if (hasDigit) count++;
  
    return count;
  }
  
 export  function DifferenceOfPrationArrays(...numbers) {
    if(!numbers.length || numbers?.length%2!==0) return 'wrong number of argument'
  const singleArrayLength = numbers.length / 2;
  let firstArrayAddition=0,secondArrayAddition=0
  for(let arrayIndex=0;arrayIndex<singleArrayLength;arrayIndex++){
    firstArrayAddition=firstArrayAddition+numbers[arrayIndex]
    secondArrayAddition=secondArrayAddition+numbers[arrayIndex+singleArrayLength]
  }
  return firstArrayAddition-secondArrayAddition
}

  export const addFun=(a,b)=>{
    return a+b
  }
