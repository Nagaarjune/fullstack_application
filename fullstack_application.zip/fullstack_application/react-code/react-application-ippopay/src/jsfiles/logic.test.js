import {addFun,DifferenceOfPrationArrays,minimumStepsToMakePasswordStrong} from './logics'

describe("Calculator tests", () => {
    test('adding 1 + 2 should return 3', () => {
      expect(addFun(1,2)).toBe(3);
    });
   })


 describe('testing difference of partition of numbers',()=>{
    test('checking for empty numbers',()=>{
       expect(DifferenceOfPrationArrays()).toBe('wrong number of argument')
    })
    test('checking for passing total length of odd number',()=>{
        expect(DifferenceOfPrationArrays(1,2,3)).toBe('wrong number of argument')
     })
     test('checking for scenario1',()=>{
        expect(DifferenceOfPrationArrays(3,9,7,3)).toBe(2)
     })
     test('checking for scenario2',()=>{
        expect(DifferenceOfPrationArrays(-36,36)).toBe(-72)
     })

     //Here what i was confused or that example was wrong in question i think
     test('checking for scenario3',()=>{
        expect(DifferenceOfPrationArrays(2,-1,0,4,-2,-9)).toBe(8)
     })
 })  

 describe('testing how many steps completed for validating strong password',()=>{
    test('checking for empty string',()=>{
       expect(minimumStepsToMakePasswordStrong('')).toBe(0) 
       //Here what it will return number of steps completed
    })
    test('testing for scenario 1',()=>{
        expect(minimumStepsToMakePasswordStrong('a')).toBe(1) 
     })
     test('testing for scenario2',()=>{
        expect(minimumStepsToMakePasswordStrong('a1')).toBe(2)
     })
     test('checking number of length sholud more than 6',()=>{
        expect(minimumStepsToMakePasswordStrong('a1A')).toBe(4)
     })

     test('checking for three continous letters occurence',()=>{
        expect(minimumStepsToMakePasswordStrong('A1aaa')).toBe(3)
        //Here all conditions will satified except contionus three continous letters
     })
     test('checking number of length sholud less than 20',()=>{
        expect(minimumStepsToMakePasswordStrong('a1Aaaba1Aaaba1Aaaba1Aaab')).toBe(4)
     })
     test('testing for scenario6',()=>{
        expect(minimumStepsToMakePasswordStrong('a1Aaab')).toBe(5)
     })
 })  