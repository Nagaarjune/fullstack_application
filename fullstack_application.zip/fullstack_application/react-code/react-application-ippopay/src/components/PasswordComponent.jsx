import {TextField,Button}  from '@material-ui/core'
import {useCommonClasses} from './Styles'
import React,{useState} from 'react'
import {minimumStepsToMakePasswordStrong} from '../jsfiles/logics'
import {createPassword} from './../apicall'
import { ToastContainer, toast } from 'react-toastify';
  import 'react-toastify/dist/ReactToastify.css';

  const initialValue={
    statusMessgae:`step 0 of 5 completed`,
    passwordValue:'',
    stepCount:0
  }

export default function PasswordComponent(){
    const [passwordAttributes,setPasswordAttributes]=useState(initialValue)
    
    const classNames=useCommonClasses()

    const storePassword=async()=>{
        try{
        const result=await createPassword(passwordAttributes.passwordValue)
        toast(result.message)
        setPasswordAttributes(initialValue)
        }
        catch(e){
console.log('error',e)
        }
    }
    const handleChangePassword=(value)=>{
        const passwordAttributeData={...passwordAttributes}
        passwordAttributeData.passwordValue=value
        const stepCount =minimumStepsToMakePasswordStrong(value)
        passwordAttributeData.stepCount = stepCount
        passwordAttributeData.statusMessgae=stepCount !==5 ?`step ${stepCount} of 5 completed`:''
        
        setPasswordAttributes(passwordAttributeData)

    }

    return(
    <div>
        <p className={classNames.header}>Enter a strong password</p>
<div className={classNames.passwordParentContainer}>
    <div className={classNames.passwordChildContainer}>
        <TextField
        placeholder='enter password'
        value={passwordAttributes.passwordValue}
        onChange={({target})=>{handleChangePassword(target.value)}}
        variant="outlined"
        helperText={passwordAttributes.statusMessgae}
        error={passwordAttributes.stepCount !==5 ? true : false}
        className={classNames.textboxContainer}
        >
        </TextField>
    </div>
    
    <div className={classNames.passwordChildContainer}>
        <Button className={classNames.storeButtonstyle} onClick={storePassword} disabled={passwordAttributes.stepCount !==5 ? true :false}>
Store
        </Button>
    </div>
    <ToastContainer/>
</div>
    </div>
    )
} 