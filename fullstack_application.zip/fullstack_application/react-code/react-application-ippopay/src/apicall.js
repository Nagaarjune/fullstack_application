import Axios from 'axios'

export const createPassword= async (password)=>{
    return new Promise((resolve,reject)=>{
         Axios.post('https://rdmh97sni5.execute-api.us-east-1.amazonaws.com/dev/createPassword',{password}).then((res)=>{
            resolve(res.data)
         }).catch((err)=>{
            console.log('error',err)
            reject(err)
         }
         )
    })
}
