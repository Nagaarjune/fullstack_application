import logo from './logo.svg';
import './App.css';
import PasswordComponent from './components/PasswordComponent'

function App() {
  return (
    <div className="App">
      <PasswordComponent></PasswordComponent>
        
    </div>
  );
}

export default App;
